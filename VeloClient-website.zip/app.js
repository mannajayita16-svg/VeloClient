const $ = (s) => document.querySelector(s);
const loginModal = $("#loginModal");
const appModal = $("#appModal");

document.querySelectorAll("[data-open-login]").forEach(btn => {
  btn.addEventListener("click", () => loginModal.classList.remove("hidden"));
});
document.querySelectorAll("[data-close-login]").forEach(btn => {
  btn.addEventListener("click", () => loginModal.classList.add("hidden"));
});

$("#loginForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const email = $("#email").value.trim();
  localStorage.setItem("veloclient_user", email);
  loginModal.classList.add("hidden");
  appModal.classList.remove("hidden");
});

$("#demoLogin").addEventListener("click", () => {
  localStorage.setItem("veloclient_user", "demo@veloclient.com");
  loginModal.classList.add("hidden");
  appModal.classList.remove("hidden");
});

$("#closePortal").addEventListener("click", () => appModal.classList.add("hidden"));

$("#askAi").addEventListener("click", async () => {
  const input = $("#aiPrompt");
  const output = $("#aiResponse");
  const prompt = input.value.trim();
  if (!prompt) {
    output.textContent = "Type a request first — for example: “Draft a friendly update for a client whose project is delayed.”";
    return;
  }
  output.textContent = "Thinking…";
  try {
    const response = await fetch("/api/gemini", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({prompt})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "AI request failed");
    output.textContent = data.text || "No response returned.";
  } catch (err) {
    output.textContent = "Gemini is not connected yet. Deploy the included API endpoint and add GEMINI_API_KEY as a server environment variable. Demo request: " + prompt;
  }
});

if (localStorage.getItem("veloclient_user")) {
  // Keeps the login UI ready without automatically opening the portal.
}
