// Vercel serverless function.
// Add GEMINI_API_KEY in your Vercel Project Settings -> Environment Variables.
// Never put your Gemini API key in index.html, app.js, or any public GitHub file.

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    return res.status(500).json({ error: "GEMINI_API_KEY is not configured on the server." });
  }

  try {
    const { prompt } = req.body || {};
    if (!prompt || typeof prompt !== "string") {
      return res.status(400).json({ error: "A prompt is required." });
    }

    const model = "gemini-2.5-flash";
    const url =
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;

    const upstream = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{
            text: "You are VeloClient's concise business assistant. Help with client onboarding, project updates, summaries, proposals and professional communication. Do not invent financial or client facts."
          }]
        },
        contents: [{ role: "user", parts: [{ text: prompt.slice(0, 6000) }] }],
        generationConfig: { temperature: 0.4, maxOutputTokens: 700 }
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      return res.status(upstream.status).json({
        error: data?.error?.message || "Gemini API request failed."
      });
    }

    const text =
      data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") ||
      "Gemini returned no text.";

    return res.status(200).json({ text });
  } catch (error) {
    return res.status(500).json({ error: "Server error while contacting Gemini." });
  }
}
